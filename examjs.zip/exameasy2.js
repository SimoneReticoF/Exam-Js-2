//esercizio1
const arrayStringhe = ['casa', 'albero', 'gatto', 'sole', 'libro', 'tavolo'];

const mappaLunghezze = new Map();
for (let parola of arrayStringhe) {
  mappaLunghezze.set(parola, parola.length);
}

for (let [parola, lunghezza] of mappaLunghezze) {
  console.log(`La parola "${parola}" contiene ${lunghezza} caratteri.`);
}



//esercizio2
function dammiPersoneOrdinate(persone) {
    return persone.sort((a, b) => a.età - b.età);
  }
  
  const persone = [
    { nome: 'Mario Rossi', età: 32 },
    { nome: 'Luigi Verdi', età: 25 },
    { nome: 'Peach Pink', età: 30 }
  ];
  
  const personeOrdinate = dammiPersoneOrdinate(persone);
  
  for (let persona of personeOrdinate) {
    console.log(persona);
  }

  
//esercizio 3 
const arrayStringhe = ['casa', 'albero', 'gatto', 'sole', 'libro', 'tavolo'];

const mappaLunghezze = new Map();
for (let parola of arrayStringhe) {
  mappaLunghezze.set(parola, parola.length);
}

mappaLunghezze.forEach((lunghezza, parola) => {
  console.log(`La parola "${parola}" contiene ${lunghezza} caratteri.`);
});

//esercizio 5
function stampaCaratteriUnivoci(stringa) {
    const caratteri = {};
    for (let carattere of stringa) {
      if (caratteri[carattere]) {
        caratteri[carattere]++;
      } else {
        caratteri[carattere] = 1;
      }
    }
  
    const caratteriUnivoci = Object.keys(caratteri).filter(carattere => caratteri[carattere] === 1);
    
    return caratteriUnivoci.join('');
  }
  
  const stringa = 'abbazia';
  const caratteriUnivoci = stampaCaratteriUnivoci(stringa);
  console.log(caratteriUnivoci);
  

  
  





    