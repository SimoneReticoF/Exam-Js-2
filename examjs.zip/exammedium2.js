//esercizio 1
const numeri = [5, 12, 2, 8, 15, -3];
const numeriMaggioriDi10 = numeri.filter(numero => numero > 10);
const numeriInferioriA1 = numeri.filter(numero => numero < 1);

const differenza = numeriMaggioriDi10.length - numeriInferioriA1.length;

if (differenza === 0) {
  console.log("Numeri in senso invertito:", numeri.reverse());
} else {
  console.log("Primo numero:", numeri[0]);
  console.log("Ultimo numero:", numeri[numeri.length - 1]);
}

console.log("Differenza:", differenza);

//esercizio 2 
function confrontaSetNumeri(set1, set2) {
    const risultato = {};

    const numeroElementiSet1 = set1.size;
    const numeroElementiSet2 = set2.size;
  
    if (numeroElementiSet1 > numeroElementiSet2) {
      risultato.winner = 1;
    } else if (numeroElementiSet1 < numeroElementiSet2) {
      risultato.winner = 2;
    } else {
      risultato.winner = 0;
    }
  
    const numeriPositiviSet1 = [...set1].filter(numero => numero > 0).length;
    const numeriPositiviSet2 = [...set2].filter(numero => numero > 0).length;
  
    if (numeriPositiviSet1 > numeriPositiviSet2) {
      risultato.morePositive = 1;
    } else if (numeriPositiviSet1 < numeriPositiviSet2) {
      risultato.morePositive = 2;
    } else {
      risultato.morePositive = 0;
    }
  
    return risultato;
  }
  
  const setNumeri1 = new Set([1, 2, 3, -4, -5]);
  const setNumeri2 = new Set([6, 7, -8, -9, -10]);
  
  const confronto = confrontaSetNumeri(setNumeri1, setNumeri2);
  console.log(confronto);
  
  //esercizio 3

  function opeRettangolo(rect1, rect2, operazione) {
    const perimetro1 = 2 * (rect1.x + rect1.y);
    const perimetro2 = 2 * (rect2.x + rect2.y);
    const area1 = rect1.x * rect1.y;
    const area2 = rect2.x * rect2.y;
  
    if (operazione === 'perimetro') {
      return perimetro1 - perimetro2;
    } else if (operazione === 'area') {
      return area1 + area2;
    } else {
      return 'Operazione non valida.';
    }
  }
  
  const rect1 = { x: 5, y: 3 };
  const rect2 = { x: 7, y: 2 };
  
  const differenzaPerimetri = opeRettangolo(rect1, rect2, 'perimetro');
  const sommaAree = opeRettangolo(rect1, rect2, 'area');
  
  console.log('Differenza tra perimetri:', differenzaPerimetri);
  console.log('Somma delle aree:', sommaAree);

  //esercizio 4 

  function opeStringa(stringa, trasformazione) {
    return trasformazione(stringa);
  }
  
  function uc(stringa) {
    return stringa.toUpperCase();
  }
  
  function odd(stringa) {
    let risultato = '';
    for (let i = 0; i < stringa.length; i++) {
      if (i % 2 !== 0) {
        risultato += stringa[i];
      }
    }
    return risultato;
  }
  
 
  function invert(stringa) {
    return stringa.split('').reverse().join('');
  }
  
  const s = "javascript";
  
  const risultato1 = opeStringa(s, uc);
  console.log(risultato1); // Output: JAVASCRIPT
  
  const risultato2 = opeStringa(s, odd);
  console.log(risultato2); // Output: aacit
  
  const risultato3 = opeStringa(s, invert);
  console.log(risultato3); // Output: tpircsavaj
  
  